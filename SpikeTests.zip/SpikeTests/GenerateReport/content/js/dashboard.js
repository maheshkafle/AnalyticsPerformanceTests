/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 99.58276289197471, "KoPercent": 0.417237108025295};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.22100528065714845, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.16269718527683266, 500, 1500, "GetProductionPerHourContainerData"], "isController": false}, {"data": [0.0, 500, 1500, "Get authorization code"], "isController": false}, {"data": [0.25511889035667107, 500, 1500, "GetQuantityProducedContainerData"], "isController": false}, {"data": [0.5, 500, 1500, "Generate access token"], "isController": false}, {"data": [0.39340727048675295, 500, 1500, "GetAllMachine"], "isController": false}, {"data": [0.21915254237288134, 500, 1500, "GetProductionPerDayContainerData"], "isController": false}, {"data": [0.058159722222222224, 500, 1500, "GetMachineOverviewData"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 15339, 64, 0.417237108025295, 7751.9216376556615, 242, 240152, 1719.0, 5680.0, 21090.0, 224853.20000000007, 9.687883293185577, 33.325299702902385, 14.157846400328298], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["GetProductionPerHourContainerData", 3233, 35, 1.0825858335910918, 15729.452830188715, 266, 240152, 2148.0, 21662.999999999996, 126456.6999999999, 236046.45999999988, 2.082116404024609, 19.370787782676445, 3.1821407932602668], "isController": false}, {"data": ["Get authorization code", 1, 0, 0.0, 5480.0, 5480, 5480, 5480.0, 5480.0, 5480.0, 5480.0, 0.18248175182481752, 0.4594120666058394, 0.0], "isController": false}, {"data": ["GetQuantityProducedContainerData", 3028, 4, 0.13210039630118892, 6701.136723910176, 243, 240140, 1535.5, 3626.0, 17342.699999999964, 228282.1, 1.9514345428403683, 1.7131228797161009, 2.9766999569498584], "isController": false}, {"data": ["Generate access token", 1, 0, 0.0, 985.0, 985, 985, 985.0, 985.0, 985.0, 985.0, 1.0152284263959392, 2.4190989847715736, 0.48877696700507617], "isController": false}, {"data": ["GetAllMachine", 3246, 0, 0.0, 3423.913123844735, 540, 132398, 913.5, 2320.000000000002, 5373.5999999999985, 86754.75999999978, 2.0887291633822485, 8.934212632435788, 2.7781729692642796], "isController": false}, {"data": ["GetProductionPerDayContainerData", 2950, 18, 0.6101694915254238, 5731.169152542383, 242, 240144, 1701.0, 3804.8, 5401.749999999997, 223470.08999999994, 1.901299973575153, 3.0955395432126815, 2.8965116784933973], "isController": false}, {"data": ["GetMachineOverviewData", 2880, 7, 0.24305555555555555, 6852.4052083333345, 308, 240147, 3221.5, 8115.000000000003, 18401.19999999999, 79395.49, 1.8562525741002491, 0.861283771873004, 2.6067296890196863], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["504/Gateway Timeout", 17, 26.5625, 0.11082860681921898], "isController": false}, {"data": ["499", 12, 18.75, 0.07823195775474281], "isController": false}, {"data": ["500/Internal Server Error", 35, 54.6875, 0.2281765434513332], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 15339, 64, "500/Internal Server Error", 35, "504/Gateway Timeout", 17, "499", 12, "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["GetProductionPerHourContainerData", 3233, 35, "500/Internal Server Error", 22, "504/Gateway Timeout", 8, "499", 5, "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["GetQuantityProducedContainerData", 3028, 4, "504/Gateway Timeout", 2, "499", 2, "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["GetProductionPerDayContainerData", 2950, 18, "500/Internal Server Error", 13, "499", 3, "504/Gateway Timeout", 2, "", "", "", ""], "isController": false}, {"data": ["GetMachineOverviewData", 2880, 7, "504/Gateway Timeout", 5, "499", 2, "", "", "", "", "", ""], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
